<!-- Title -->
<h1 class="page-header-title mb-3 d-flex align-items-center gap-2">
    <img src="{{dynamicAsset('public/assets/admin/img/basic-seo.png')}}" alt="">
    Basic SEO
</h1>

<!-- Nav Menus -->
<ul class="nav nav-tabs border-0 nav--tabs nav--pills mb-4">
    <li class="nav-item">
        <a class="nav-link active" href="#">Web Master Tool</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Robot.txt</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Site Map</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">Robots Meta Content</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="#">404 Logs</a>
    </li>
</ul>
