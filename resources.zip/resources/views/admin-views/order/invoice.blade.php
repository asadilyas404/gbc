@extends('layouts.admin.app')

@section('title',translate('messages.Order_Invoice'))

@section('content')
    @include('new_invoice')
@endsection
